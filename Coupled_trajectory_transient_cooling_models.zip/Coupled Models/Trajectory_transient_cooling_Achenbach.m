%%Transient cooling of a hot spherical projectile in-flight
%Transport and transient cooling models coupled with the Achenbach (1978)
%hequation for Nu-Re-Pr relationship

clc;
clear all;
format short e;

global A B C D DU PI

% ***** ASSIGN INPUT DATA AND START THE OUTPUT ON A NEW PAGE *****
RHO = 3000.0; % Pyroclast density [kg/m3]
RHOF = 1.2;  % Fluid (air/gas) density [kg/m3]
G = 9.81; % Acceleration due to gravity [m/s^2]
dt = 0.1; % Time step [s]
IFRPRT = 5; 
t0 = 0.0;  % Initial time [s]
X0 = 0.0;  % Initial position in the x-direction [m]
Y0 = 0.0;  % Initial position in the y-direction [m]
W0 = 100.0; % Initial speed [m/s]
RHOBAR = RHOF/RHO;
DU = 1.821E-5; % fluid (air) dynamic viscosity [kg/m s]; (Matthews et al. 1976)
PI = 3.142857; % PI = pi;
D = 0.1; % Pyroclast diameter [m]
A = 1. + RHOBAR/2.;
B = (1. - RHOBAR)*G;  
C = 3.*RHOBAR/(4.*D);
% coefficient values in Achenbach (1978) equation
a = 0.5E-3; 
b = 0.25E-9;
c = -3.1E-17;

%%Temperature parameters initialization
Tl = 1433.15;  % initial/erupting temp. of basalt [K]
% Tl = 1373.15;  % erupting temp. of basalt [K]
ka = 0.0257; % thermal conductivity of air [W/m.K]
k = 1.9;    %  1.6 -2.2 [W/m.K] (Eppelbaum et al.1996)
Pr = 0.71; % Prandtl number for air
% htc = 6000; % heat transfer coefficient in [Watt/m^2.K]
Ta = 298.15; % ambient temp. [K]
alpha = 10^-5; % thermal diffusivity of basalt [m^2/s]((Huppert and Sparks, 1988; Jellinek and Kerr, 1999)

nr = 100;   % number of indices or radial positions
h = (D/2)/nr; % radial spacing
ITMAX = 5000; % Maximum iteration
s = (alpha*dt)/h^2; % assigning the constansts to a term, s

% ***** PRINTING HEADINS AND ASSIGN INITIAL CONDITIONS FOR EACH OF THE 3
% CASES WITH THETA0 = 30, 45 AND 60 DEGREES, RESPECTIVELY. THEN PRINT THE
% INITIAL VALUES *****

THETA00 = [30]; % exit angle 

for THETA0 = THETA00
    N = 1
   % THETA0 = THETA0 + 15.0;
    P = 1;
    t(P) = t0;
    X(P) = X0;
    Y(P) = Y0;
    U(P) = W0 * cos(THETA0*PI/180.);  % ball vel in the x-direction
    V(P) = W0 * sin(THETA0*PI/180.);  % ball vel in the y-direction

% ***** FOURTH-ORDER RUNGE-KUTTA METHOD IS USED TO INTEGRATE THE EQUATIONS
% OF MOTION, STOP THE COMPUTATION FOR ONE CASE IF THE PROJECTILE DROPS BACK
% TO ITS INITIAL LEVEL OR BELOW, PRINT DATA WHEN THE LAST TIME STEP IS
% REACHED OR WHEN THE COUNT P IS AN INTEGRAL MULTIPLE OF IFRPRT *****

    disp([[[[[['CASE(' num2str(N)] ') ***** INITIAL SPEED ='] num2str(W0)] ' M/SEC.    THETA0 ='] num2str(THETA0)] ' DEGREES']);
    disp('       t            X            Y            U            V   ');
    disp('     (SEC)         (M)          (M)        (M/SEC)      (M/SEC)');

    disp([t(P) X(P) Y(P) U(P) V(P)]);

    while (Y(P) >= 0.)
        [TSOL,SOL] = ode45(@FXY, [t(P), t(P)+dt], [X(P), U(P), Y(P), V(P)]);
        P = P + 1;
        t(P)=TSOL(end);
        X(P)=SOL(end,1);
        U(P)=SOL(end,2);
        Y(P)=SOL(end,3);
        V(P)=SOL(end,4);
        if (rem(P-1,IFRPRT) == 0)
            disp([t(P) X(P) Y(P) U(P) V(P)]);
        end
    end

    disp([t(P) X(P) Y(P) U(P) V(P)]);
    clear plot
    txt = ['Angle = ',num2str(THETA0)];
    plot(X,Y,'DisplayName',txt);
    xlabel('Range/Distance, {\it x} (m)'),ylabel('Height, {\it y} (m)');
    % title(['Trajectory of a ball of basalt with initial velocity = 50 m/s in air (air speed = 20 m/s) at ' ,num2str(THETA0), ' ^o']);
    hold on
   
end
    nt = round(t(end)/dt);   % total flight time is assigned to the transient cooling timestep size
    T = zeros(nt,nr); % initialize the temperature grid
    wr = sqrt((U.^2) + (V.^2)); % resultant particle velocity [m/s]
    RE_P = (abs(wr) * 1.2 * D)/DU; % particle Reynolds number
    
for J = 1 
    for I = 1:1:nr
        T(J,I) = Tl;  % assigns erupting temperature to all radial positions at first timestep
    end
end 

tic
for J = 2:1:nt
    RP = RE_P(J); % particle Reynolds number for each timestep
    savRP(J) = RP;

    ITER = 0;
    ERROR = 1.0;   

%*** THE GAUSS SEIDEL ITERATION STEP

while (ERROR > 0.0001 && ITER < ITMAX)
    ITER = ITER + 1;
    ERROR = 0; 

    if (RP > 100) && (RP < 3E5)
    htc = ((2*ka)+(ka*(((0.25*RP) + (3E-4*(RP^1.6)))^0.5)))/D; % Heat transfer coefficent using Nu-Re-Pr relationship
    else if (RP > 3E5) && (RP < 5E6)
            htc = (ka*(430 + (a*RP) + (b*(RP^2)) + (c*(RP^3))))/D;
    end
    end
    savhtc(J) = htc;
    timehtc = savhtc(:);
for I = 1
    T(J,I) = T(J,I+1);
end
for I = nr
   T(J,I) = ((htc*Ta) + ((k*T(J,I-1))/h))/(htc + (k/h)); % Forced convectional cooling at rim or last radial position
end
    
        for I = 2:1:nr-1
            T_old = T(J,I);
            T(J,I) = (T(J-1,I) + (T(J,I+1)*(s+(alpha*dt)/(I*h^2))) + (T(J,I-1)*(s-(alpha*dt)/(I*h^2))))/(1+(2*s)); % transient cooling         
            ERROR = ERROR + abs(T(J,I) - T_old);           
        end  
end
    
end
qr = (max(T(1,:))-min(T(end,:)))/t(end);
Tg = 577000/(2.303*8.314*(log10(qr)+30.8)); % glass transition temperature estimation (Giordano et al. 2005; Gottsmann et al. 2002; Wilding et al. 1996)
Tg = Tg-273;
toc
T = T-273.15; % convert T from [K] to [deg. celsius]
 figure();
    
    plot(dt:dt:(nt*dt),T(:,50));
    hold on;
    plot(dt:dt:(nt*dt),T(:,60));
    hold on;
    plot(dt:dt:(nt*dt),T(:,70));
    hold on;
    plot(dt:dt:(nt*dt),T(:,80));
    hold on;
    plot(dt:dt:(nt*dt),T(:,95));
    yline(Tg,'k',LineWidth=3);
    set(gca, 'Xscale', 'log');
    ylabel("Temperature, {\it T} (°C)");
    xlabel("Time, {\it t} (s)");
    legend('2.5 cm','3 cm','3.5 cm','4 cm','4.5 cm','{\itT_g}');
    title("Achenbach's criterion: Transient cooling of 10 cm basalt, wind speed of 15 ms^-^1");
    figure();
    plot(dt:dt:(nt*dt)+dt,T(10,:));
    hold on;
    plot(dt:dt:(nt*dt)+dt,T(30,:));
    hold on;
    plot(dt:dt:(nt*dt)+dt,T(50,:));
    hold on;
    plot(dt:dt:(nt*dt)+dt,T(70,:));
    hold on;
    plot(dt:dt:(nt*dt)+dt,T(90,:));
    set(gca, 'Xscale', 'log');
    set(gca, 'Yscale', 'log');
    yline(670,'red',LineWidth=2);
    % title(['Cooling profile (from core to rim) of 0.05 m spherical basalt upon landing from '  ,num2str(THETA0), '^o flight'])
    xlabel('Time, {\it t} (s)');
    ylabel('Temperature, {\it T} (^oC)');
legend('0.5 s','0.6 s','0.7 s','0.8 s','0.9 s');

