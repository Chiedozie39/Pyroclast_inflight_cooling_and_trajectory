%%Transient cooling of a hot spherical projectile in-flight
%Transport and transient cooling models coupled with the Whitaker (1972) 
%equation for Nu-Re-Pr relationship

clc;
clear all;
format short e;

global A B C D DU PI

% ***** ASSIGN INPUT DATA AND START THE OUTPUT ON A NEW PAGE *****
RHO = 3000.0; % Pyroclast density [kg/m3]
RHOF = 1.2;  % Fluid (air/gas) density [kg/m3]
G = 9.81; % Acceleration due to Earth's gravity [m/s^2]
dt = 0.01; % Time step [s]
IFRPRT = 5; 
t0 = 0.0;  % Initial time [s]
X0 = 0.0;  % Initial position in the x-direction [m]
Y0 = 0.0;  % Initial position in the y-direction [m]
W0 = 100.0; % Initial speed [m/s]
RHOBAR = RHOF/RHO;
DU = 1.821E-5; % Fluid (air) dynamic viscosity [kg/m s]; (Matthews et al. 1976)
PI = 3.142857; % PI = pi;
D = 0.1; % Pyroclast diameter [m]
A = 1. - RHOBAR/2.;
B = (1. - RHOBAR)*G;  
C = 3.*RHOBAR/(4.*D);
% Viscosity model constant terms for...(specify lava type and calculate b and c using the viscosity model of Giordano et al., 2008)
%For Kilauea sideromelane (from Marsh et al., 2024; Giordano et al., 2008);
a = -4.55;
b = 5596.12;   % Dacite:b = 7646.69; c = 204.19
c = 618.59;

% Temperature parameters initialization
Tl = 1373.15;  % initial/erupting temp. of basalt [K]
ka = 0.0257; % thermal conductivity of air [W/m.K]
k = 1.9; % thermal conductivity of basalt, 1.6 -2.2 [W/m.K] (Eppelbaum et al.1996)
Pr = 0.71; %Prandtl number for air
% htc = 6000;      %heat transfer coefficient in [Watt/m^2.K]
Ta = 298.15; % ambient temp. [K]
alpha = 10^-5; % thermal diffusivity of basalt [m^2/s]((Huppert and Sparks, 1988; Jellinek and Kerr, 1999)
UP = 1000; % viscosity at mean bulk temperature
UW = DU; % viscosity at mean wall temperature (at initial time)

nr = 101; % number of indices or radial positions
h = (D/2)/nr; % radial spacing
ITMAX = 5000; % maximum number of iterations for each time step
s = (alpha*dt)/h^2; % assigning the constansts to a term, s

% ***** PRINTING HEADINS AND ASSIGN INITIAL CONDITIONS FOR EACH OF THE 3
% CASES WITH THETA0 = 30, 45 AND 60 DEGREES, RESPECTIVELY. THEN PRINT THE
% INITIAL VALUES *****

THETA00 = [30]; % exit angle 

for THETA0 = THETA00
    N = 1
   % THETA0 = THETA0 + 15.0;
    P = 1;
    t(P) = t0;
    X(P) = X0;
    Y(P) = Y0;
    U(P) = W0 * cos(THETA0*PI/180.);  % ball vel in the x-direction
    V(P) = W0 * sin(THETA0*PI/180.);  % ball vel in the y-direction

% ***** FOURTH-ORDER RUNGE-KUTTA METHOD IS USED TO INTEGRATE THE EQUATIONS
% OF MOTION, STOP THE COMPUTATION FOR ONE CASE IF THE PROJECTILE DROPS BACK
% TO ITS INITIAL LEVEL OR BELOW, PRINT DATA WHEN THE LAST TIME STEP IS
% REACHED OR WHEN THE COUNT P IS AN INTEGRAL MULTIPLE OF IFRPRT *****

    disp([[[[[['CASE(' num2str(N)] ') ***** INITIAL SPEED ='] num2str(W0)] ' M/SEC.    THETA0 ='] num2str(THETA0)] ' DEGREES']);
    disp('       t            X            Y            U            V   ');
    disp('     (SEC)         (M)          (M)        (M/SEC)      (M/SEC)');

    disp([t(P) X(P) Y(P) U(P) V(P)]);

    while (Y(P) >= 0.)
        [TSOL,SOL] = ode45(@FXY, [t(P), t(P)+dt], [X(P), U(P), Y(P), V(P)]);
        P = P + 1;
        t(P)=TSOL(end);
        X(P)=SOL(end,1);
        U(P)=SOL(end,2);
        Y(P)=SOL(end,3);
        V(P)=SOL(end,4);
        if (rem(P-1,IFRPRT) == 0)
            disp([t(P) X(P) Y(P) U(P) V(P)]);
        end
    end

    disp([t(P) X(P) Y(P) U(P) V(P)]);
    clear plot
    txt = ['Angle = ',num2str(THETA0)];
    plot(X,Y,'DisplayName',txt);
    xlabel('Range/Distance, {\it x} (m)'),ylabel('Height, {\it y} (m)');
    % title(['Trajectory of a ball of basalt with initial velocity = 50 m/s in air (air speed = 20 m/s) at ' ,num2str(THETA0), ' ^o']);
    hold on
   
end
    nt = round(t(end)/dt); % total flight time is assigned to the transient cooling timestep size
    T = zeros(nt,nr); % initialize the temperature grid
    wr = sqrt((U.^2) + (V.^2)); % resultant particle velocity at each timestep [m/s]
    RE_P = (abs(wr) * 1.2 * D)/DU; % particle Reynolds number
    
for J = 1
    for I = 1:1:nr
        T(J,I) = Tl; % assigns erupting temperature to all radial positions at first timestep
    end
end 

tic
for J = 2:1:nt
    RP = RE_P(J); % particle Reynolds number for each timestep
    [re, idx] = min(RE_P);

    ITER = 0;
    ERROR = 1.0;   

%*** THE GAUSS SEIDEL ITERATION STEP

while (ERROR > 0.0001 && ITER < ITMAX)
    ITER = ITER + 1;
    ERROR = 0; 
    
    htc = (ka*(2 + (((Pr^0.4)*((UP/UW)^0.25))*((0.4*(RP^0.5)) + (0.06*(RP^(2/3)))))))/D; %Heat transfer coefficent using Nu-Re-Pr relationship

    savhtc(J) = htc;
    timehtc = savhtc(:);
for I = 1
    T(J,I) = T(J,I+1);
end
% %% 2 THERMAL/FOUNTAIN ZONES
% if J < idx 
%     Ta = Tl;
% else Ta = 298.15;
% end
% %% FOR 3 THERMAL/FOUNTAIN ZONES
% if J <= ((2/3)*idx) %&& max(X) < 0.5*(max(Y))
%     Ta = 1000; %inner fountain zone
% else if J > ((2/3)*idx) && J < ((2/3)*(size(RE_P,2)))
%         Ta = 600; %intermediate fountain zone
% else if J > ((2/3)*(size(RE_P,2))) || J <= nt 
%         Ta  = 298.15; %ambient temperature
% end
% end
% end
% savTa(J) = Ta;
savRP(J) = RP;
SAVUP(J) = UP;
SAVUW(J) = UW;


for I = nr
   T(J,I) = ((htc*Ta) + ((k*T(J,I-1))/h))/(htc + (k/h)); % Forced convectional cooling at rim or last radial position
end
    
        for I = 2:1:nr-1
            T_old = T(J,I);
            T(J,I) = (T(J-1,I) + (T(J,I+1)*(s+(alpha*dt)/(I*h^2))) + (T(J,I-1)*(s-(alpha*dt)/(I*h^2))))/(1+(2*s)); % transient cooling 
            UP = 10^((a + (b/(mean(T(J,1:end-1))-c)))); % bulk viscosity calculation 
            UW = 10^((a+(b/(max(T(:,nr))-c)))); % wall viscosity calculation 

            ERROR = ERROR + abs(T(J,I) - T_old);           
        end  
end
    
end
qr = (max(T(1,:))-min(T(end,:)))/t(end);
Tg = 577000/(2.303*8.314*(log10(qr)+30.8)); % glass transition temperature estimation (Giordano et al. 2005; Gottsmann et al. 2002; Wilding et al. 1996)
Tg = Tg-273;
toc
T = T-273.15; % convert T from [K] to [deg. celsius]

 figure();
      %  plot(h:h:((D/2)), T(50,:));
    %  hold on;
    %  plot(h:h:((D/2)), T(end,:),'--r');
    plot(dt:dt:(nt*dt),T(:,20),"Color",'#67001f','LineWidth',2);
    hold on;
    plot(dt:dt:(nt*dt),T(:,40),"Color",'#d95319','LineWidth',2);
    hold on;
    plot(dt:dt:(nt*dt),T(:,60),"Color",'#f4a582','LineWidth',2);
    hold on;
    plot(dt:dt:(nt*dt),T(:,80),"Color",'#4393c3','LineWidth',2);
    hold on;
    plot(dt:dt:(nt*dt),T(:,100),"Color",'#053061','LineWidth',2);
    yline(Tg,':k',LineWidth=3);
    set(gca, 'Xscale', 'log');
   % legend('1 cm','2 cm','3 cm','4 cm','5 cm');
   legend('3 cm','6 cm','9 cm','12 cm','14.85 cm');
   ylabel("Pyroclast temperature, {\itT} (°C)");
   xlabel("Time since ejection from vent, {\itt} (s)");
   
     figure();
    plot(0:dt:(nt*dt),T(10,:));
    hold on;
    plot(0:dt:(nt*dt),T(30,:));
    hold on;
    plot(0:dt:(nt*dt),T(50,:));
    hold on;
    plot(0:dt:(nt*dt),T(70,:));
    hold on;
    plot(0:dt:(nt*dt),T(90,:));
    set(gca, 'Xscale', 'log');
    set(gca, 'Yscale', 'log');
    yline(670,'red',LineWidth=2);
    % title(['Cooling profile (from core to rim) of 0.05 m spherical basalt upon landing from '  ,num2str(THETA0), '^o flight'])
    xlabel('Time, {\it t} (s)');
    ylabel('Temperature, {\it T} (^oC)');
legend('0.5 s','0.6 s','0.7 s','0.8 s','0.9 s');


