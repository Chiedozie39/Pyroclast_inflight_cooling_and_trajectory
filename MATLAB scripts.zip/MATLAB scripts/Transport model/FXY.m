function [RES] = FXY(t,VEC);

global A B C D DU PI

X = VEC(1);
U = VEC(2);
Y = VEC(3);
V = VEC(4);


UF = 15.0; % Fluid vel in the x direction
VF = 0.0; % Fluid vel in the y direction
WR = sqrt( (UF-U)^2 + (VF-V)^2 );  % Fluid vel relative to the body vel

% A, B and C are defined in the main script
FX = C*CD(WR)*(UF-U)*WR/A; %Eq 11

FY = ( -B + C*CD(WR)*(VF-V)*WR )/A; %Eq 12

RES = [U; FX; V; FY];
