                        
% MOTION AND TRAJECTORY OF A SPHERICAL PYROCLAST IN AN ACTIVE FLUID
% Reference: Computational Fluid Mechanics by Example (Biringen and Chow; Wiley 2011)
clf;
clc;
clear all;
format short e;

global A B C D DU PI

% ***** ASSIGN INPUT DATA AND START THE OUTPUT ON A NEW PAGE *****
RHO = 2500; % Pyroclast density [kg/m3]
RHOF = 1.22;  % Fluid (air/gas) density [kg/m3]
G = 9.81; % Acceleration due to gravity [m/s^2]
dt = 0.1; % Time step [s]
IFRPRT = 5; 
t0 = 0.0;  % Initial time [s]
X0 = 0.0;  % Initial position in the x-direction [m]
Y0 = 0.0;  % Initial position in the y-direction [m]
W0 = 100; % Exit speed [m/s]
RHOBAR = RHOF/RHO;
DU = 1.821E-5; % fluid (air) dynamic viscosity (kg/m s); (Matthews et al. 1976)
PI = 3.14159; 
% PI = pi;
D = 0.48; % Pyroclast diameter [m]
A = 1. + RHOBAR/2.;
B = (1. - RHOBAR)*G;
C = 3.*RHOBAR/(4.*D);


% ***** PRINTING HEADINS AND ASSIGN INITIAL CONDITIONS FOR EACH OF THE 3
% CASES WITH THETA0 = 30, 45 AND 60 DEGREES, RESPECTIVELY. THEN PRINT THE
% INITIAL VALUES *****
THETA00 = [30,45,70,85];

for THETA0 = THETA00
    N = 1   
    P = 1;
    t(P) = t0;
    X(P) = X0;
    Y(P) = Y0;
    U(P) = W0 * cos(THETA0*PI/180.);  % ball vel in the x-direction
    V(P) = W0 * sin(THETA0*PI/180.);  % ball vel in the y-direction

% ***** FOURTH-ORDER RUNGE-KUTTA METHOD IS USED TO INTEGRATE THE EQUATIONS
% OF MOTION, STOP THE COMPUTATION FOR ONE CASE IF THE PROJECTILE DROPS BACK
% TO ITS INITIAL LEVEL OR BELOW, PRINT DATA WHEN THE LAST TIME STEP IS
% REACHED OR WHEN THE COUNT P IS AN INTEGRAL MULTIPLE OF IFRPRT *****

    disp([[[[[['CASE(' num2str(N)] ') ***** INITIAL SPEED ='] num2str(W0)] ' M/SEC.    THETA0 ='] num2str(THETA0)] ' DEGREES']);
    disp('       t            X            Y            U            V   ');
    disp('     (SEC)         (M)          (M)        (M/SEC)      (M/SEC)');

    disp([t(P) X(P) Y(P) U(P) V(P)]);

    while (Y(P) >= 0.)
        [TSOL,SOL] = ode45(@FXY, [t(P), t(P)+dt], [X(P), U(P), Y(P), V(P)]);
        P = P + 1;
        t(P)=TSOL(end);
        X(P)=SOL(end,1);
        U(P)=SOL(end,2);
        Y(P)=SOL(end,3);
        V(P)=SOL(end,4);
        if (rem(P-1,IFRPRT) == 0)
            disp([t(P) X(P) Y(P) U(P) V(P)]);
        end
    end

    disp([t(P) X(P) Y(P) U(P) V(P)]);
    clear plot
    txt = ['Angle = ',num2str(THETA0)];
    hold on;
    % Ballistic = xlsread('Trajectory','Mastin');
    % x_Mast = Ballistic(:,2);
    % y_Mast = Ballistic(:,3);
    plot(X,Y,'DisplayName',txt);
    % hold on;
    % plot(x_Mast,y_Mast,"--k");
    xlabel('Range/Distance, {\it x} (m)'),ylabel('Height, {\it y} (m)');
    title(['Trajectories for pyroclasts launched at exit angles of 30^o, 45^o, 60^o and 80^o']);
    hold on
    legend
   
end 
% max(X)
% max(Y)
% t(end)
